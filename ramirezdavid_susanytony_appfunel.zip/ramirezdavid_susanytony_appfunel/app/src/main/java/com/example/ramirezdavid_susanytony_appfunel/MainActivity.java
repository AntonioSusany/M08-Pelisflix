package com.example.ramirezdavid_susanytony_appfunel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button loginButton = findViewById(R.id.btn_login);

        // Configurar el botón de inicio de sesión
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aquí puedes añadir validación para los campos (email, password)

                // Llamar a la segunda actividad
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);  // Iniciar la segunda actividad
            }
        });
    }
}
