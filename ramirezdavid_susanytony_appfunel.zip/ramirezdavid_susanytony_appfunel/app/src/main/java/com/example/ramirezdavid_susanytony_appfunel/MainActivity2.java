package com.example.ramirezdavid_susanytony_appfunel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    private EditText etLupa;
    private Button btnBuscar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        etLupa = findViewById(R.id.et_lupa);
        btnBuscar = findViewById(R.id.btn_buscar);

        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String texto = etLupa.getText().toString().trim();


                if (texto.isEmpty()) {

                    Toast.makeText(MainActivity2.this, "Por favor, ingresa un género.", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent intent;


                if (texto.equalsIgnoreCase("Accion")) {
                    intent = new Intent(MainActivity2.this, MainActivity3.class);
                } else if (texto.equalsIgnoreCase("Drama")) {
                    intent = new Intent(MainActivity2.this, MainActivity4.class);
                } else if (texto.equalsIgnoreCase("Infantil")) {
                    intent = new Intent(MainActivity2.this, MainActivity5.class);
                } else {

                    Toast.makeText(MainActivity2.this, "Género no encontrado.", Toast.LENGTH_SHORT).show();
                    return;
                }


                startActivity(intent);
            }
        });
    }
}
