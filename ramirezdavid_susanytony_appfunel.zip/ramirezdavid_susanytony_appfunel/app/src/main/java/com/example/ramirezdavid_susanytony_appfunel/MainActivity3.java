package com.example.ramirezdavid_susanytony_appfunel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    private TextView textView2;
    private ImageButton imageButton;
    private Button button1, button2, button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);


        textView2 = findViewById(R.id.textView2);
        imageButton = findViewById(R.id.imageButton);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);


        String textoRecibido = getIntent().getStringExtra("texto");


        if (textoRecibido != null && !textoRecibido.isEmpty()) {
            textView2.setText(textoRecibido);
        } else {
            textView2.setText("Texto no disponible"); // Mensaje alternativo
        }


        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Finaliza esta actividad y regresa a la anterior
            }
        });


        View.OnClickListener openActivity6Listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity6();
            }
        };


        button1.setOnClickListener(openActivity6Listener);
        button2.setOnClickListener(openActivity6Listener);
        button3.setOnClickListener(openActivity6Listener);
    }


    private void openActivity6() {
        Intent intent = new Intent(MainActivity3.this, MainActivity6.class); // Cambia a tu Activity6
        startActivity(intent);
    }
}
