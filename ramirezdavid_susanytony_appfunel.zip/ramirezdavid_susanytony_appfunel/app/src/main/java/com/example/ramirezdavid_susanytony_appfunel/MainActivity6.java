package com.example.ramirezdavid_susanytony_appfunel;

import android.content.Intent;  // Importa Intent
import android.os.Bundle;
import android.view.View;
import android.widget.Button;  // Importa el Button
import android.widget.ImageButton;  // Asegúrate de importar ImageButton
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);


        ImageButton btnVolver = findViewById(R.id.btn_volver);


        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        Button btnPagar = findViewById(R.id.btnPagar);


        btnPagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity7();
            }
        });
    }


    private void openActivity7() {
        Intent intent = new Intent(MainActivity6.this, MainActivity7.class);  // Crea la Intent para MainActivity7
        startActivity(intent);
    }
}
